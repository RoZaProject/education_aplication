import LandingPage from "./pages/LandingPage";

function App() {
  return (
    <div>
      <h2>Land App</h2>
      <LandingPage />
    </div>
  );
}

export default App;
