import AuthorisationPage from "./pages/AuthorisationPage";

function App() {
  return (
    <div>
      <h2>Auth App</h2>
      <AuthorisationPage />
    </div>
  );
}

export default App;
