import HomePage from './pages/HomePage';

function App() {
  return (
    <div>
      <h2>Dashboard App</h2>
      <HomePage />
    </div>
  );
}

export default App;
