import ResultsPage from './pages/ResultsPage';

function App() {
  return (
    <div>
      <h2>Result App</h2>
      <ResultsPage />
    </div>
  );
}

export default App;
